import React from "react";

function Note() {
  return (
    <div className="note">
      <h1> Javascript and react.js</h1>
      <p>This is me Deepali.R ,ive gained a lot of knowlegde and it was a amazing bootcamp and as well as informative
        </p>
      </div>
  )
}

export default Note;